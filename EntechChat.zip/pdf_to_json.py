import pdfplumber
import json

def pdf_to_json(pdf_path, json_path):
    catalog = []

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if not text:
                continue

            lines = text.split("\n")
            for line in lines:
                # простой парсер: ищем строки с названием и мощностью
                if "Вт" in line or "W" in line:
                    catalog.append({
                        "name": line.strip(),
                        "raw": line
                    })

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(catalog, f, ensure_ascii=False, indent=2)

    print(f"Saved {len(catalog)} items to {json_path}")

if __name__ == "__main__":
    pdf_to_json("catalog.pdf", "catalog.json")
