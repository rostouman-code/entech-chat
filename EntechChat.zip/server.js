import express from "express";
import bodyParser from "body-parser";
import fs from "fs";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();

const app = express();
app.use(bodyParser.json());

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Загружаем каталог
let catalog = [];
try {
  const raw = fs.readFileSync("catalog.json", "utf-8");
  catalog = JSON.parse(raw);
  console.log("Catalog loaded:", catalog.length, "items");
} catch (e) {
  console.error("Error loading catalog.json:", e.message);
}

app.post("/chat", async (req, res) => {
  const { message } = req.body;

  const prompt = `
You are a smart and friendly AI assistant for Entech, a company that manufactures LED lighting.
Use the catalog JSON below to recommend suitable products.

Catalog: ${JSON.stringify(catalog.slice(0, 10))} 

User message: ${message}
`;

  try {
    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "system", content: prompt }],
    });

    const reply = response.choices[0].message.content;
    res.json({ reply });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI request failed" });
  }
});

app.listen(3000, () => console.log("Server running on http://localhost:3000"));
